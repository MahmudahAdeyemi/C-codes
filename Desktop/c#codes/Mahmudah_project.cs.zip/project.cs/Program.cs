﻿namespace  Method
{
    public   class Program
    {
        
        static void Main(string[] args)
        {
            Console.WriteLine("Welcome to JUSTRITE SUPERSTORE");
            Menu menu = new Menu();
            menu.My_menu();
            Console.WriteLine("Thanks for Patronage");
        }



        
    }
}



