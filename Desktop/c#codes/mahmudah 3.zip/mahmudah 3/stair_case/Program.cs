﻿int num = 3;
int count = 0;
while (num > count)
{
    num = num - (count + 1);
    count ++;
    
}
Console.WriteLine(count);