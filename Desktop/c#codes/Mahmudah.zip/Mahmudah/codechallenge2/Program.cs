﻿Console.Write("Enter number of words you want to check: ");
int lenght = int.Parse(Console.ReadLine());
string [] array = new string[lenght];
for (int i = 0; i < lenght; i ++)
{
   Console.Write("Enter the word one by one: ");
   array[i] = (Console.ReadLine());
}
for(int i = 0; i < lenght; i ++ )
{
    if((array[i].Substring(0,i)) == (array[lenght - 1 -i].Substring(0,(i+1)))  )
    {
        Console.Write(array[i].Substring(0,i));
    }
}