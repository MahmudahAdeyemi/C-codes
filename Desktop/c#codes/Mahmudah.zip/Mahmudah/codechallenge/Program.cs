﻿Console.Write("Enter a valid character: ");
string Mychar =( Console.ReadLine());
if (Mychar == "{}" || Mychar == "[]" || Mychar == "()" )
{
    Console.WriteLine("True ");
}
else
{
    Console.WriteLine("False");
}