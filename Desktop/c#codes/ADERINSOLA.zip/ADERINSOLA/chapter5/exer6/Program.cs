﻿int a = 1;
int b = 61;
int c = 900;
int d = (b*b);
int e = (a * c );
int f = (4 * e);
int g = (d - f);
Console.WriteLine(g);
double x = Math.Sqrt(g);
Console.WriteLine(x);
double y= (-b + x);
Console.WriteLine(y);
double z = (y/(2*a));
Console.WriteLine(z);-

