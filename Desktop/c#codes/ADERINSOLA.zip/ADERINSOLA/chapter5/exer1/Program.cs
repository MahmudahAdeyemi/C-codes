﻿int a  = 21;
int b = 40;
bool c = ( a < b );
if (c)
{
    b = a;
    Console.WriteLine(b);

    
}