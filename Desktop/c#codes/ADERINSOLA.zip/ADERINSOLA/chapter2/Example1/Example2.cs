public class Example2{

    public static int Add (int a, int b){

        int c = a + b;
        return c;
    }
}