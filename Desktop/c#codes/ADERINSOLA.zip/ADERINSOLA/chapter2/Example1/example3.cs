public class Example3{

    public static int subtract (int a, int b){
        int c = a - b;
        return c;
    }
}