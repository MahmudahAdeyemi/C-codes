byte centuries = 20;
unshort years = 2000;
uint days = 30807;
ulong hours = 17564897;
Console.Writeline(centuries + "centuries are"+years+"years,or"+days+"days,or"+hours+"hours.");
