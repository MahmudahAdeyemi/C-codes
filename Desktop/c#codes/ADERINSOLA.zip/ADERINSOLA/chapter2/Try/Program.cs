﻿//char ch = 'a';
//Console.WriteLine(
//"The code of '" + ch + "' is: " + (int)ch);
//ch = 'b';
//Console.WriteLine(
//"The code of '" + ch + "' is: " + (int)ch);
//ch = 'c';
//Console.WriteLine(
//"The code of '" + ch + "' is: " + (int)ch);
//ch = 'd';
//Console.WriteLine(
//"The code of '" + ch + "' is: " + (int)ch);
//ch = 'e';
//console.WriteLine(
//"The code of '" + ch + "' is: " + (int)ch);
//ch = 'f';
//Console.WriteLine(
//"The code of '" + ch + "' is: " + (int)ch);
//string str = "Hello World!";
//Console.Write("{0}", str);


int a = 45;
int b = 19;
int c = 12;
bool d = (a > b) & (a > c);
if (d)
{
    Console.WriteLine("bdeuyg");
}