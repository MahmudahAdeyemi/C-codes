﻿string a = "male";
string b = "female";
bool Bmale = (b == a);
bool Afemale = (a == b);
if (Bmale)
{
    Console.WriteLine("b is male");
}
else
{
    Console.WriteLine("b is female");
    
}