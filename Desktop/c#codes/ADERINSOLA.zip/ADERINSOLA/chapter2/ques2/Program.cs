﻿char ch = 'H';
Console.WriteLine(
    "The code of "+ch+" is " + (int)ch);
