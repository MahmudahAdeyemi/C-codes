﻿int a =100;
Console.WriteLine(a);
