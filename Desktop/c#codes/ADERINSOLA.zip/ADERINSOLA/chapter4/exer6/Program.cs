﻿int a = 5;
int b = 7;
Console.WriteLine(Math.Max(a,b));