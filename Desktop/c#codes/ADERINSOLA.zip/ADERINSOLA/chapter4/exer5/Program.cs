﻿int a = 15;
int b = 30;
int c = ((b-a)/5);
int d = c + 1;
Console.WriteLine(d+" numders are divisible by 5");