﻿int r = 7;
double area = (Math.PI * r * r);
double perimeter = (2 * Math.PI * r);
Console.WriteLine("The area of the circle is "+area+"and the circumference is "+perimeter+".");