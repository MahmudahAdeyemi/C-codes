﻿class Standnumeric
{
    static void Main()
    {
        Console.WriteLine("{0:X}", 7456783451);
        Console.WriteLine("{0:F2}", 74567.3451);
        Console.WriteLine("{0:F2}", -546.546);
    }
}
