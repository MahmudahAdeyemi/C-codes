﻿int n = 9;
for (int i = 1; i <= n; i ++)
{
    Console.WriteLine(i + " ");
}
