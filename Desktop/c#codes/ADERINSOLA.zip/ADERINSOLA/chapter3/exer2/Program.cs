﻿int num = 7;
int solve =num % 2;
bool myCheck = (solve == 0);
if (myCheck)
{
    Console.WriteLine(num+" is an even number");

}
else
{
    Console.WriteLine(num+" is an odd number");
}

