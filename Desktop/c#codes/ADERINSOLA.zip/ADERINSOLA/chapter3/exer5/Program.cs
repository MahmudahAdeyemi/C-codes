﻿int a = 5;
int b = 4;
int h = 6;
int area = ((a+b)*h/2);
Console.WriteLine("the area of the trapezium is "+area+".");
