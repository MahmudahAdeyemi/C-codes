﻿bool symetric = true;
Console.WriteLine("Enter the lenght of the array: ");
int n = int.Parse(Console.ReadLine());
int [] array = new int [n];
for (int i = 0; i < n; i++)
{
    array[i] = int.Parse(Console.ReadLine());
}
for (int j=0;j<n/2;j ++)
{
    if (array [j] != array[n-j-1])
    {
        symetric = false;
        break;

    }

}
Console.WriteLine(symetric);
